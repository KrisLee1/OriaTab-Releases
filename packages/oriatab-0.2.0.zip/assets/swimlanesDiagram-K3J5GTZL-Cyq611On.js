import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-BbHDS76q.js";import"./chunk-VPRB5NB3-DuZI99lT.js";import"./chunk-3YJQHVM4-BtRK9Ix9.js";import"./chunk-HJ2JQQFS-ClVm3483.js";import"./chunk-E2ZNV5FY-DoHwmcl1.js";import"./chunk-4EA7E6EY-CwFTM4TP.js";import"./chunk-XC4XBNZT-BfZTgERH.js";import"./chunk-DBDB3WZW-BWhFb8Qh.js";import"./chunk-2BW5OAIV-BRTONieF.js";import"./chunk-7TKQ45FW-DCjdIfhw.js";import"./chunk-XXDRQBXY-RlzOQ08v.js";import"./chunk-KQW6MTUR-Dcr-3mxa.js";import"./chunk-NTY3LDVX-C9JGYJLM.js";import{r as t,t as n}from"./chunk-EU5HNXII-BdVu6MXx.js";import"./mermaid-diagram-C3xRAmpc.js";var r=n({styles:e(e=>`${t(e)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};